/*
SQLyog Ultimate v12.09 (32 bit)
MySQL - 5.5.50 : Database - dynamic_quiz
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dynamic_quiz` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dynamic_quiz`;

/*Table structure for table `admin_login` */

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(5) DEFAULT NULL,
  `admin_email` varchar(70) DEFAULT NULL,
  `password` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin_login` */

insert  into `admin_login`(`id`,`admin_email`,`password`) values (1,'vivgangs@gmail.com','1234');

/*Table structure for table `options` */

DROP TABLE IF EXISTS `options`;

CREATE TABLE `options` (
  `opt_id` int(5) NOT NULL AUTO_INCREMENT,
  `options` varchar(100) DEFAULT NULL,
  `position` int(5) DEFAULT NULL,
  `ques_id` int(5) DEFAULT NULL,
  `right_answer` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`opt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

/*Data for the table `options` */

insert  into `options`(`opt_id`,`options`,`position`,`ques_id`,`right_answer`) values (1,'Hyperlinks and Text Markup Language',1,1,0),(2,'Home Tool Markup Language',2,1,0),(3,'Hyper Text Markup Language',3,1,1),(4,'None of The Above',4,1,0),(5,'h6',1,2,0),(6,'&lt;Heading &gt;',2,2,0),(7,'&lt;Head &gt;',3,2,0),(8,'h1',4,2,1),(9,'br',1,3,1),(10,'&lt;break&gt;',2,3,0),(11,'&lt;linebreak&gt;',3,3,0),(12,'&lt;lb&gt;',4,3,0),(13,'&lt;',1,4,0),(14,'&gt;',2,4,0),(15,'&lt;end&gt;',3,4,0),(16,'None of The Above',4,4,1),(17,' Target_blank',1,5,1),(18,'&lt;a href=new tab &gt;',2,5,0),(19,'&lt;a href=\"target_new_tab\" &gt;',3,5,0),(20,'None of The Above',4,5,0),(21,'&lt;table create&gt;',1,6,0),(22,'table',2,6,1),(23,'&lt;new table&gt;',3,6,0),(24,'&lt;tbody&gt;',4,6,0),(25,'True',1,7,1),(26,'False',2,7,0),(27,'&lt;number list&gt;',1,8,0),(28,'&lt;ul &gt;',2,8,0),(29,' ol ',3,8,1),(30,'&lt; lt &gt;',4,8,0),(31,' ul ',1,9,1),(32,'&lt; bulleted &gt;',2,9,0),(33,'&lt; bullet_list &gt;',3,9,0),(34,'None of The Above',4,9,0),(35,' input type checkbox ',1,10,1),(36,'&lt; checkbox &gt;',2,10,0),(37,'&lt; check &gt;',3,10,0),(38,'&lt; input type=\"check \" &gt;',4,10,0),(39,' input type text',1,11,1),(40,'&lt; textfield &gt;',2,11,0),(41,'&lt; input type =\" text-field\" &gt;',3,11,0),(42,'None of The Above',4,11,0);

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `ques_id` int(5) NOT NULL AUTO_INCREMENT,
  `question` varchar(200) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ques_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `questions` */

insert  into `questions`(`ques_id`,`question`,`type`) values (1,'What does HTML stand for?','HTML'),(2,'Choose the correct HTML element for the largest heading:','HTML'),(3,'What is the correct HTML element for inserting a line break?','HTML'),(4,'Which character is used to indicate an end tag?','HTML'),(5,'How can you open a link in a new tab/browser window?','HTML'),(6,'Tag used for creating table is?','HTML'),(7,'Inline elements are normally displayed without starting a new line.','HTML'),(8,'How can you make a numbered list?','HTML'),(9,'How can you make a bulleted list?','HTML'),(10,'What is the correct HTML for making a checkbox?','HTML'),(11,'What is the correct HTML for making a text input field?','HTML');

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `password` varchar(80) DEFAULT NULL,
  `cpassword` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`id`,`firstname`,`lastname`,`email`,`password`,`cpassword`) values (27,'vaibhav','Gangrade','vivgangs1@gmail.com','Password123','Password123');

/*Table structure for table `result` */

DROP TABLE IF EXISTS `result`;

CREATE TABLE `result` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) DEFAULT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `right_ans` int(5) DEFAULT NULL,
  `wrong_ans` int(5) DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `test_time` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=latin1;

/*Data for the table `result` */

insert  into `result`(`id`,`user_id`,`user_name`,`lname`,`right_ans`,`wrong_ans`,`test_date`,`test_time`) values (146,26,'Vaibhav','Gangrade',6,5,'2018-09-24','12:13:43'),(147,26,'Vaibhav','Gangrade',7,4,'2018-09-24','12:16:16'),(148,27,'vaibhav','Gangrade',9,2,'2018-09-24','15:20:21'),(149,27,'vaibhav','Gangrade',9,2,'2018-09-24','15:23:29'),(150,27,'vaibhav','Gangrade',9,2,'2018-09-24','15:35:33'),(151,27,'vaibhav','Gangrade',11,0,'2018-09-24','16:24:35'),(152,27,'vaibhav','Gangrade',0,11,'2018-09-24','16:41:49'),(153,27,'vaibhav','Gangrade',4,7,'2018-09-24','17:04:38'),(154,27,'vaibhav','Gangrade',6,5,'2018-09-24','17:10:28'),(155,27,'vaibhav','Gangrade',7,4,'2018-09-24','17:14:32'),(156,27,'vaibhav','Gangrade',7,4,'2018-09-24','17:15:52'),(157,27,'vaibhav','Gangrade',7,4,'2018-09-24','17:30:52'),(158,27,'vaibhav','Gangrade',9,2,'2018-09-24','17:32:16'),(159,27,'vaibhav','Gangrade',9,2,'2018-09-24','18:10:47'),(160,27,'vaibhav','Gangrade',5,6,'2018-09-24','18:19:54'),(161,27,'vaibhav','Gangrade',11,0,'2018-09-24','18:30:54'),(162,27,'vaibhav','Gangrade',7,4,'2018-09-24','18:39:08'),(163,27,'vaibhav','Gangrade',8,3,'2018-09-24','18:46:49');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
