function checkUser(){

var firstname=$('#firstname').val();
var lastname=$('#lastname').val();
var email=$('#email').val();
var password=$('#pwd').val();
var cpassword=$('#conf_pwd').val();


 
  if (firstname=="") {
$('#firstnamechk').show();
$('#firstnamechk').css('color', '#CC0000');
$('#firstnamechk').html('Please enter firstname.');
$('#firstname').focus();
$('#firstname').addClass('error');
setTimeout("$('#firstnamechk').fadeOut(); ", 3000);
return false;
}
 
 else if (lastname=="") {
$('#lastnamechk').show();
$('#lastnamechk').css('color', '#CC0000');
$('#lastnamechk').html('Please enter lastname.');
$('#lastname').focus();
$('#lastname').addClass('error');
setTimeout("$('#lastnamechk').fadeOut(); ", 3000);
return false;
}

else if(email==""){
$('#chkemail').show();
$('#chkemail').css('color','#CC0000');
$('#chkemail').html('please enter email');
$('#email')	.focus();
$('#email').addClass('error');
setTimeout("$('#chkemail').fadeOut();",3000);
return false;
	
}
else if(password==""){
	
	$('#chkpwd').show();
	$('#chkpwd').css('color','#CC0000');
	$('#chkpwd').html('please enter your password');
	$('#pwd').focus();
	$('#pwd').addClass('error');
	setTimeout("$('#chkpwd').fadeOut();",3000);
	return false;
	
}
else if(cpassword==""){
	
	$('#cpwd').show();
	$('#cpwd').css('color','#CC0000');
	$('#cpwd').html('please reenter your password');
	$('#conf_pwd').focus();
	$('#conf_pwd').addClass('error');
	setTimeout("$('#cpwd').fadeOut();",3000);
	return false;
}
 
 else if(cpassword!=password){
	
	$('#cpwd').show();
	$('#cpwd').css('color','#CC0000');
	$('#cpwd').html('password not matched');
	$('#conf_pwd').focus();
	$('#conf_pwd').addClass('error');
	setTimeout("$('#cpwd').fadeOut();",3000);
	return false;
}
 
 
 
 
else {
$('form#register').submit();
}
}