<?php
include("inc/header.php");
include("inc/connection.php");
?><br><br><br><br>
<div class="container">
  <h2>User test results:</h2>
             
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Sno<?php $no=0;?></th>
        <th>User id</th>
		 <th>First Name</th>
		  <th>Last Name</th>
		  <th>Email</th>
        <th>Right Answers</th>
		<th>Wrong Answers</th>
		<th>Date of test</th>
		<th>Time of test</th>
      </tr>
	  
    </thead>
<tbody>
<?php
$select_query="SELECT * FROM result";
$res=mysqli_query($conn,$select_query);
if(mysqli_num_rows($res)>0){
	
	while($rs=mysqli_fetch_assoc($res)){
		?>
		
		
		<tr>
        <td><?php echo ++$no; ?></td>
        <td><?php echo $rs['user_id']; ?></td>
		<td><?php echo $rs['user_name'];?></td>
		<td><?php echo $rs['lname'];?></td>
		<td><?php echo $rs['uemail'];?></td>
        <td><?php echo $rs['right_ans']; ?></td>
		<td><?php echo $rs['wrong_ans']; ?></td>
        <td><?php echo $rs['test_date']; ?></td>
        <td><?php echo $rs['test_time']; ?></td>
      </tr>
		
		<?php
	}
}
else
{
	?>
	<tr>
		<td colspan="7"><b>No Data Found</b></td>
	</tr>
		<?php

}


?>

			
		
      
    </tbody>
  </table>
  </div>