<?php
include("inc/connection.php");
?>
<?php
if(isset($_POST['submit'])){

	extract($_POST);
	
	$select_query="SELECT * FROM questions WHERE question='$question'";
	$res1=mysqli_query($conn,$select_query);
	if(mysqli_num_rows($res1)>0){
		
		echo "This question is already available";
		
	}
	else{
	
		$insert_query="INSERT INTO questions(question,type)VALUES('$question','$type')";
		$res=mysqli_query($conn,$insert_query);

		if($res!=true){
			die("can not insert").mysqli_error();
			
		}
		else{
			
			//echo"inserted";
			header("location:adddata.php");	
			}
}
}
?>