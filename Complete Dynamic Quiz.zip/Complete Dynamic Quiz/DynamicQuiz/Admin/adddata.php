<?php
include("inc/header.php");
include("inc/connection.php");
?><br><br>
<script src="js/insert_quest.js"></script>
<div class="container">
<h1>Insert more Questions: </h1>
<form action="insert.php" method="POST" onsubmit="return insertQuest();" id="insertQuestions">
			<div class="form-group">
				<input class="form-control" placeholder="Question" type="text" name="question" id="quest"/>
					<div id="insertQuest" class="popup_error"></div>
			</div>

			<div class="form-group">
				<input class="form-control" placeholder="Type of Question" type="text" name="type" id="type_quest" pattern="^[a-zA-Z]*$" title="Only letters are required" />
					<div id="insert_type" class="popup_error"></div>
			</div>
<input type="submit" class="btn btn-primary" name="submit">

</form>

</div>