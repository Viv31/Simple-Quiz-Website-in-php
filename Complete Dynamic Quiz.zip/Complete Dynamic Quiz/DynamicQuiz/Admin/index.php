<?php
session_start();
if(isset($_SESSION['admin_email'])){
	unset($_SESSION['admin_email']);
}
?>
<?php
include("inc/connection.php");
if(isset($_POST['submit'])){
	
	$admin_email=$_POST['admin_email'];
	$pass=$_POST['password'];
	
	$select_query="SELECT * FROM admin_login WHERE admin_email='$admin_email' and password='$pass'";
	$res=mysqli_query($conn,$select_query);
	if(mysqli_num_rows($res)>0){
		
		$_SESSION['admin_email']=$admin_email;
		
		header("location:home.php");
		
	}
	else{
		
		echo"your are not adimn";
	}
	
	
	
	
	
}

?>
<br>
<br>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="js/admin_login_valid.js"></script>
  <link rel="stylesheet" href="css/admin_form_css.css">
</head>
<body>

<div class="container">
  <h2>Admin login form</h2>
  <form action="index.php" method="POST" id="admin_login" onsubmit="return admlogin();">
  
  <div class="form-group">
	<input type="email" name="admin_email" id="admin_email" placeholder="Enter your email here" class="form-control">
		<div id="errormsg" class="popup_error"></div>
  </div>
  
  <div class="form-group">
	<input type="password" name="password" id="admin_pass" placeholder="Enter your password here" class="form-control">
		<div id="errorpass" class="popup_error"></div>
  </div>
  
  
  <div class="from-group">
  <input type="submit" name="submit" value="submit" class="btn btn-primary">
  </div>
