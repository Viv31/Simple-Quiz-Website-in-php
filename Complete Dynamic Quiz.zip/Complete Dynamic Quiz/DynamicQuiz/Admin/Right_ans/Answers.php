<?php
session_start();
if(!isset($_SESSION['email']))
{
	header("location:index.php");
}
if(isset($_POST['logout'])){
	
	header("location:../../index.php");
}
session_unset();

?>

<?php
include("../inc/connection.php");
//include("header.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Quiz Website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap.min.css">
  <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap.min.js"></script>

<br><br>
<div class="container">
  <h2>Right Answers</h2>
             
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Sno</th>
        <th>Question</th>
        <th>Answer</th>
      </tr>
	  </thead>
    <tbody>
	  <?php
	  $select_query="SELECT * FROM questions";
	  $res=mysqli_query($conn,$select_query);
	  if(mysqli_num_rows($res)>0){
		  
		  while($rs=mysqli_fetch_assoc($res)){
			  ?>
			  
      <tr>
        <td><?php echo $rs['ques_id'];?></td>
        <td><?php echo $rs['question'];?></td>
		
        <td><?php 
		$select_query2="SELECT * FROM options Where ques_id='".$rs['ques_id']."'";
		$res2=mysqli_query($conn,$select_query2);
		if(mysqli_num_rows($res2)>0){
			
			while($rs2=mysqli_fetch_assoc($res2)){
				if($rs2['ques_id'] && $rs2['right_answer']==1){
					echo $rs2['options'];
					
				}
			}
		}
		
		
		
		?></td>
      </tr>
      
    
			  
			  
			<?php  
		  }
		  
	  }
	  
	  ?>
    </tbody>
  </table>
</div>

</body>
</html>
