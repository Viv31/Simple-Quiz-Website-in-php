<?php
include("inc/connection.php");
?>
<?php
if(isset($_POST['submit'])){
	//extract($_POST);
	
	$options=$_POST['options'];
	//echo $options;
	
	$position=$_POST['position'];
	//echo $position;
	
	$ques_id=$_POST['question'];
	//echo $ques_id;
	
	$right_answer=$_POST['right_answer'];
	
	//echo $right_answer;
	
	
	
	
	
$insert_query="INSERT INTO options(options,position,ques_id,right_answer)Values('$options','$position','$ques_id','$right_answer')";
$res=mysqli_query($conn,$insert_query);
echo $insert_query;
if($res!=true){
	
	echo "not inserted";
}
else{
	//echo"inserted";
	header("location:addoptions.php");
}
}
?>