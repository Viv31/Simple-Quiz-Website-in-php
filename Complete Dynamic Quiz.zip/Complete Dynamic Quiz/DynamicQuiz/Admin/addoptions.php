<?php
include("inc/header.php");
include("inc/connection.php");
?>
<br><br><br>
<script src="js/insertopt.js"></script>
<div class="container">
<form action="addopt.php" method="POST" onsubmit="return insertOpt();">

			<label for="Options">Options:</label>
				<div class="form-group">
				<input class="form-control" placeholder="Options" type="text" name="options" id="optiid"/>
					<div id="optionschk" class="popup_error"></div>
				</div>
			
			 <div class="form-group">
      <label for="inserted Questions">Inserted Questions:</label>
      <select class="form-control" id="quest" name="question">
	 <option value="" disabled selected>Select Question here</option>
	  <?php
	 
	  $select_query="SELECT * FROM questions";
	  $res=mysqli_query($conn,$select_query);
	  if(mysqli_num_rows($res)>0){
		  
		  while($rs=mysqli_fetch_array($res)){
			  ?>
			   
			  <option value="<?php echo $rs['ques_id'];?>"><?php echo $rs['question'];?></option>
			  <?php
		  }
		  
		  
	  }
	  
	  ?>
        
        
		</select>
	  </div>
	  
	  
	  
			<label for="position">Position of Option:</label>
			<div class="form-group">
			<select name="position" class="form-control" id="pos">
			<option value="" disabled selected>Select Position here</option>
			<?php
			for($i=1;$i<=10;$i++){
				echo "<option value=".$i.">".$i."</option>";
			}
			
			?>
			  
			</select>
			</div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<label for="answer">Answer Status</label>
			<div class="form-group">
				<label class="radio-inline">
				<input type="radio" name="right_answer" id="rightans" value="1" required>Right Answer</label>
				<label class="radio-inline">
				<input type="radio" name="right_answer" id="wrongans" value="0">Wrong Answer</label>
					<div id="answerchk" class="popup_error"></div>
			</div>
			
			
			
			
			

<input type="submit" name="submit" value="submit" class="btn btn-primary">
</form>







</div>