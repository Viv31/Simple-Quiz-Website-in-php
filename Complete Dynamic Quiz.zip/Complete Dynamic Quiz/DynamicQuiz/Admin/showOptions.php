<?php
include("inc/header.php");
?>
<br><br>
		<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
				var dataTable = $('#insopt').DataTable( {
					"processing": true,
					"serverSide": true,
					"ajax":{
						url :"optiondata.php", // json datasource
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".insopt-error").html("");
							$("#insopt").append('<tbody class="insopt-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
							$("#insopt_processing").css("display","none");
							
						}
					}
				} );
			} );
		</script>
		<style>
		.butt{
			float:right;
			width:90px;
			font-color:black;
		}
		
		.butt:hover{
			background:#1A5276;
			border:1px solid black;
			
			
		}
		
		</style>
		
	</head>
	<body>
	
		
		<div class="container">
		<h1>Options inserted</h1>
		<a href="addoptions.php" style="text-decoration:none;color:white;"><button type="button" class="btn btn-info btn-lg butt" name="add" value="add">Add</button></a>
		<br>
			<table id="insopt"  class="table table-hover" width="100%">
					<thead>
						<tr>
							<th>Option Id</th>
							<th>Option</th>
							<th>Position</th>
							<th>Question Id</th>
							<th>Right Answer</th>
						</tr>
					</thead>
			</table>
		</div>
	</body>
</html>
