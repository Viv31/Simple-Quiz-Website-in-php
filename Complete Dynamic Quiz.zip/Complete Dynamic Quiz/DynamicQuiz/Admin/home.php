<?php
include("inc/header.php");
include("inc/connection.php");
?><br><br><br><br>
<div class="container">
<?php echo "<h4> <center>Welcome   Admin :  "."<u>" .$_SESSION['admin_email']."</ul>"."</h4></center></u>";
?>
<hr style="border-color: black;">

<h1>Registerd Users:</h1>
<table class="table table-bordered">
  <thead>
        <tr>
            <th>Sno<?php $sno=0;?></th>
              <th>First Name</th>
                <th>Last Name</th>
              <th>Email</th>
            <th>Operations</th>
        </tr>
  </thead>
  

<?php
$select_data="SELECT * FROM register";
$res=mysqli_query($conn,$select_data);
if(mysqli_num_rows($res)>0){
    while($rs=mysqli_fetch_assoc($res))
    {
      ?>
      <tbody>
        <tr>
          <td><?php echo ++$sno;?></td>
          <td><?php echo $rs['firstname'];?></td>
           <td><?php echo $rs['lastname'];?></td>
            <td><?php echo $rs['email'];?></td>
            <?php $id=$rs['id'];?>
            <td><?php echo "<a href='delete_user.php?id=$id'<button class='btn btn-danger' onclick='return del();'>Delete User</a></button>";?></td>

        </tr>


      </tbody>



<?php
    }

}

?>


</table>

<script>
  
  function del(){
   var y=confirm("Do you Really want to delete this!!!");
         if(y){
         return true;
       }
           else{
              return false;
           }
              
    }

</script>

</div>












