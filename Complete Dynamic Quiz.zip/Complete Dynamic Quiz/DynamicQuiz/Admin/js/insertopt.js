function insertOpt()
{
	var options=$('#optiid').val();
	var rightans=$('#rightans').val();
	
	if(options==""){
		
		$('#optionschk').show();
		$('#optionschk').css('color','#CC0000');
		$('#optionschk').html('options can not be empty');
		$('#optiid').focus();
		$('#optiid').addClass('error');
		setTimeout("$('#optionschk').fadeOut();",3000);
		return false;
		
		
		
	}
	
		
		
	}
	
	
	
	
	
	
