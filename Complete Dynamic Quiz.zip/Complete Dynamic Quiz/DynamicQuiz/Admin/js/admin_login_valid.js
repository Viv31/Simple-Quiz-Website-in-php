function admlogin(){
	
	var admin_email=$('#admin_email').val();
	var pass=$('#admin_pass').val();
	
	if(admin_email==""){
	$('#errormsg').show();
	$('#errormsg').css('color','#CC0000');
	$('#errormsg').html('please enter your email');
	$('#admin_email').focus();
	$('#admin_email').addClass('error');
	setTimeout("$('#errormsg').fadeOut();",3000);
	return false;
		
		
	}
	else if(pass==""){
		$('#errorpass').show();
		$('#errorpass').css('color','#CC0000');
		$('#errorpass').html('please enter your password');
		$('#admin_pass').focus();
		$('#admin_pass').addClass('error');
		setTimeout("$('#errorpass').fadeOut();",3000);
		return false;
		
	}
			else {
		$('form#admin_login').submit();
		}
	
	
}