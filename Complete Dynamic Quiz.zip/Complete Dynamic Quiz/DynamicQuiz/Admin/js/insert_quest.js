function insertQuest(){
	
	var question=$('#quest').val();
	var type=$('#type_quest').val();
	
	if(question==""){
		
		$('#insertQuest').show();
		$('#insertQuest').css('color','#CC0000');
		$('#insertQuest').html('please insert a question');
		$('#quest').focus();
		$('#quest').addClass('error');
		setTimeout("$('#insertQuest').fadeOut();",3000);
		return false;
		
		
	}
	else if(type==""){
		$('#insert_type').show();
		$('#insert_type').css('color','#CC0000');
		$('#insert_type').html('please define type of question');
		$('#type_quest').focus();
		$('#type_quest').addClass('error');
		setTimeout("$('#insert_type').fadeOut();",3000);
		return false;
		
		
	}
	else{
		
		$('form#insertQuestions').submit();
	}
	
	
	
	
	
	
}