<?php
$id=$_GET['id'];
//echo $id;
include("inc/connection.php");
?>
<?php
$delete_user="DELETE FROM register WHERE id='".$id."'";
$res=mysqli_query($conn,$delete_user);
if($res!=true){

	die("failed to delete").mysqli_error();
}
else
{
	//echo"deleted successfully";
	header("location:home.php");
}



?>