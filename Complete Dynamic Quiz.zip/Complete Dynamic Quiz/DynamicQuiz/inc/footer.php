<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="footer">
  <p>Designed and Developed By:  
  	<span style="float:right;">Er.Vaibhav Gangrade</span>
  	<p><span style="float:right;">Er.Vaibhav Gangrade</span></p>
  </p>
  
</div>

</body>
</html> 
