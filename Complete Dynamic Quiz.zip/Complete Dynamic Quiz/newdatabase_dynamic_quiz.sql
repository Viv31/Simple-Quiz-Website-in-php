/*
SQLyog Ultimate v12.09 (32 bit)
MySQL - 5.5.50 : Database - dynamic_quiz
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dynamic_quiz` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dynamic_quiz`;

/*Table structure for table `admin_login` */

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(5) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `password` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin_login` */

insert  into `admin_login`(`id`,`email`,`password`) values (1,'vivgangs@gmail.com','1234');

/*Table structure for table `options` */

DROP TABLE IF EXISTS `options`;

CREATE TABLE `options` (
  `opt_id` int(5) NOT NULL AUTO_INCREMENT,
  `options` varchar(100) DEFAULT NULL,
  `position` int(5) DEFAULT NULL,
  `ques_id` int(5) DEFAULT NULL,
  `right_answer` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`opt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `options` */

insert  into `options`(`opt_id`,`options`,`position`,`ques_id`,`right_answer`) values (1,'Home Tool Markup Language',1,1,0),(2,' Hyperlinks and Text Markup Language',2,1,0),(3,'Hyper Text Markup Language',3,1,1),(4,'None of the above',4,1,0),(5,'header',1,2,0),(6,'h2',2,2,0),(7,'h1',3,2,1),(8,'h4',4,2,0),(9,'line break',1,3,0),(10,'break',2,3,0),(11,'lb',3,3,0),(12,'br',4,3,1),(13,'ol',1,4,1),(14,'ul',2,4,0),(15,'dl',3,4,0),(16,'none',4,4,0),(17,'Javascript',1,5,1),(18,'javaScale',2,5,0),(19,'Java Standard',3,5,0),(20,'Java Stable',4,5,0),(21,'False',1,6,0),(22,' True',2,6,1);

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `ques_id` int(5) NOT NULL AUTO_INCREMENT,
  `question` varchar(200) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ques_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `questions` */

insert  into `questions`(`ques_id`,`question`,`type`) values (1,' What does HTML stand for?','html'),(2,'Choose the correct HTML element for the largest heading:','html'),(3,'What is the correct HTML element for inserting a line break?','html'),(4,'How can you make a numbered list?','html'),(5,'What is the full form of JS?','Javascript'),(6,'Inline elements are normally displayed without starting a new line.','HTML');

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `password` varchar(80) DEFAULT NULL,
  `cpassword` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`id`,`firstname`,`lastname`,`email`,`password`,`cpassword`) values (4,'vaibhav','Gangrade','abc@gmail.com','123','123'),(5,'vipul','karia','vip@gmail.com','123','123');

/*Table structure for table `result` */

DROP TABLE IF EXISTS `result`;

CREATE TABLE `result` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) DEFAULT NULL,
  `right_ans` int(5) DEFAULT NULL,
  `wrong_ans` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `result` */

insert  into `result`(`id`,`user_id`,`right_ans`,`wrong_ans`) values (1,4,0,0),(2,4,0,0),(3,4,0,6),(4,4,2,4),(5,4,6,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
